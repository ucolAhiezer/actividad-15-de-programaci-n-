package com.example.actividad_15_flutter_consumiendo_una_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
